import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { FileUp, Combine, FileDown, ArrowRight } from 'lucide-react';
import ToolCard from './components/ToolCard';
import FeatureSection from './components/FeatureSection';
import BlogSection from './components/BlogSection';
import BlogPage from './components/BlogPage';
import PrivacyPolicy from './components/PrivacyPolicy';
import ImageToPDF from './components/tools/ImageToPDF';
import PDFMerger from './components/tools/PDFMerger';
import PDFCompressor from './components/tools/PDFCompressor';

function ToolsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">PDF Tools</h1>
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Image to PDF</h2>
            <ImageToPDF />
          </div>
          <div>
            <h2 className="text-xl font-semibold mb-4">PDF Merger</h2>
            <PDFMerger />
          </div>
          <div>
            <h2 className="text-xl font-semibold mb-4">PDF Compressor</h2>
            <PDFCompressor />
          </div>
        </div>
      </div>
    </div>
  );
}

function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-blue-600 font-bold text-xl">
            <FileUp className="w-6 h-6" />
            <span>PDFTool</span>
          </div>
          <div className="hidden md:flex space-x-8">
            <a href="/tools" className="text-gray-600 hover:text-blue-600">Tools</a>
            <a href="#features" className="text-gray-600 hover:text-blue-600">Features</a>
            <a href="/blog" className="text-gray-600 hover:text-blue-600">Blog</a>
            <a href="/privacy" className="text-gray-600 hover:text-blue-600">Privacy</a>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              The Ultimate Free PDF Tool Suite
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Convert, Merge, and Compress PDFs with Ease
            </p>
            <a
              href="/tools"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:text-lg"
            >
              Start Now – 100% Free! <ArrowRight className="ml-2 w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <FeatureSection />

      {/* Blog Section */}
      <BlogSection />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 text-white font-bold text-xl mb-4">
                <FileUp className="w-6 h-6" />
                <span>PDFTool</span>
              </div>
              <p className="text-gray-400">
                Professional PDF tools for everyone. Free, secure, and easy to use.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Tools</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Image to PDF</li>
                <li>PDF Merger</li>
                <li>PDF Compressor</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>© 2024 PDFTool. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/tools" element={<ToolsPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
      </Routes>
    </Router>
  );
}

export default App;