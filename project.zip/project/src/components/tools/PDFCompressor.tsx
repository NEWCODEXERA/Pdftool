import React, { useState } from 'react';
import { PDFDocument } from 'pdf-lib';
import { FileDown } from 'lucide-react';

const PDFCompressor: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const compressPDF = async () => {
    if (!file) return;
    setLoading(true);

    try {
      const fileArrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(fileArrayBuffer);
      
      // Basic compression by removing metadata and unnecessary data
      const compressedBytes = await pdfDoc.save({
        useObjectStreams: false,
        addDefaultPage: false,
        updateFieldAppearances: false
      });

      const blob = new Blob([compressedBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = 'compressed.pdf';
      link.click();
      
      URL.revokeObjectURL(url);
      setFile(null);
    } catch (error) {
      console.error('Error compressing PDF:', error);
      alert('Error compressing PDF file');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-6">
        <label className="block mb-2 text-sm font-medium text-gray-900">
          Select PDF File to Compress
        </label>
        <input
          type="file"
          accept="application/pdf"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </div>
      
      {file && (
        <div className="mb-4">
          <p className="text-sm text-gray-600">Selected file:</p>
          <p className="mt-1 text-sm text-gray-800">{file.name}</p>
        </div>
      )}

      <button
        onClick={compressPDF}
        disabled={loading || !file}
        className="w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {loading ? (
          'Compressing...'
        ) : (
          <>
            <FileDown className="w-4 h-4 mr-2" />
            Compress PDF
          </>
        )}
      </button>
    </div>
  );
};

export default PDFCompressor;