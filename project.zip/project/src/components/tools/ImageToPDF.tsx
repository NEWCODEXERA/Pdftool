import React, { useState } from 'react';
import { PDFDocument } from 'pdf-lib';
import { FileUp } from 'lucide-react';

const ImageToPDF: React.FC = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const convertToPDF = async () => {
    if (files.length === 0) return;
    setLoading(true);

    try {
      const pdfDoc = await PDFDocument.create();

      for (const file of files) {
        const imageBytes = await file.arrayBuffer();
        let image;
        
        if (file.type.includes('png')) {
          image = await pdfDoc.embedPng(imageBytes);
        } else {
          image = await pdfDoc.embedJpg(imageBytes);
        }

        const page = pdfDoc.addPage([image.width, image.height]);
        page.drawImage(image, {
          x: 0,
          y: 0,
          width: image.width,
          height: image.height,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = 'converted.pdf';
      link.click();
      
      URL.revokeObjectURL(url);
      setFiles([]);
    } catch (error) {
      console.error('Error converting to PDF:', error);
      alert('Error converting images to PDF');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-6">
        <label className="block mb-2 text-sm font-medium text-gray-900">
          Select Images (JPG, PNG)
        </label>
        <input
          type="file"
          accept="image/jpeg,image/png"
          multiple
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </div>
      
      {files.length > 0 && (
        <div className="mb-4">
          <p className="text-sm text-gray-600">Selected files:</p>
          <ul className="mt-2 space-y-1">
            {files.map((file, index) => (
              <li key={index} className="text-sm text-gray-800">
                {file.name}
              </li>
            ))}
          </ul>
        </div>
      )}

      <button
        onClick={convertToPDF}
        disabled={loading || files.length === 0}
        className="w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {loading ? (
          'Converting...'
        ) : (
          <>
            <FileUp className="w-4 h-4 mr-2" />
            Convert to PDF
          </>
        )}
      </button>
    </div>
  );
};

export default ImageToPDF;