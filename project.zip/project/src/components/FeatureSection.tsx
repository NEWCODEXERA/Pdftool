import React from 'react';
import { Shield, Zap, DollarSign, Check } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Secure Processing',
    description: 'Your files are processed securely and deleted automatically.'
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Get your processed files in seconds, not minutes.'
  },
  {
    icon: DollarSign,
    title: 'Always Free',
    description: 'All our tools are free to use with no hidden costs.'
  },
  {
    icon: Check,
    title: 'No Watermarks',
    description: 'Get clean, professional results every time.'
  }
];

const FeatureSection: React.FC = () => {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Why Choose PDFTool?</h2>
          <p className="mt-4 text-xl text-gray-600">
            Professional features that make PDF handling a breeze
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;