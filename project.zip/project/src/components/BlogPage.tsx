import React from 'react';
import { FileUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const blogPosts = [
  {
    id: 1,
    title: 'Top 5 Benefits of Using Online PDF Tools',
    excerpt: 'Discover how online PDF tools can streamline your workflow and boost productivity. Learn about time-saving features, cost benefits, and improved organization.',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=800',
    date: 'March 15, 2024',
    readTime: '5 min read',
    category: 'Productivity'
  },
  {
    id: 2,
    title: 'How to Compress PDF Files Without Losing Quality',
    excerpt: 'Learn expert tips for reducing PDF file size while maintaining document quality. Perfect for email attachments and web uploads.',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800',
    date: 'March 12, 2024',
    readTime: '4 min read',
    category: 'Tutorials'
  },
  {
    id: 3,
    title: 'Step-by-Step Guide to Merge PDFs Online',
    excerpt: 'A comprehensive guide to combining multiple PDF files efficiently. Save time and maintain document organization.',
    image: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&q=80&w=800',
    date: 'March 10, 2024',
    readTime: '6 min read',
    category: 'Tutorials'
  },
  {
    id: 4,
    title: 'Convert Images to PDFs: A Simple Solution for Professionals',
    excerpt: 'Explore the easiest ways to convert your images to PDF format. Perfect for creating professional documents and presentations.',
    image: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&q=80&w=800',
    date: 'March 8, 2024',
    readTime: '4 min read',
    category: 'Tutorials'
  },
  {
    id: 5,
    title: 'Boost Productivity with Free PDF Tools Online',
    excerpt: 'Discover how free online PDF tools can enhance your workflow and improve productivity in your daily tasks.',
    image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=800',
    date: 'March 5, 2024',
    readTime: '5 min read',
    category: 'Productivity'
  }
];

const BlogPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 text-blue-600 font-bold text-xl">
            <FileUp className="w-6 h-6" />
            <span>PDFTool</span>
          </Link>
          <div className="hidden md:flex space-x-8">
            <Link to="/" className="text-gray-600 hover:text-blue-600">Home</Link>
            <Link to="/blog" className="text-blue-600">Blog</Link>
            <Link to="/privacy" className="text-gray-600 hover:text-blue-600">Privacy</Link>
          </div>
        </nav>
      </header>

      {/* Blog Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">PDF Tools Blog</h1>
          <p className="text-xl text-gray-600">
            Expert tips, tutorials, and insights about PDF management
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {blogPosts.map((post) => (
            <article key={post.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <span>{post.date}</span>
                  <span className="mx-2">•</span>
                  <span>{post.readTime}</span>
                  <span className="mx-2">•</span>
                  <span className="text-blue-600">{post.category}</span>
                </div>
                <h2 className="text-xl font-semibold text-gray-900 mb-3">
                  {post.title}
                </h2>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <a
                  href="#"
                  className="text-blue-600 hover:text-blue-700 font-medium inline-flex items-center"
                >
                  Read More <span className="ml-1">→</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
};

export default BlogPage;